const ow = require('./src/openwhisk');
const plugin = require('./src/testplugin');

module.exports.main = ow(plugin);
