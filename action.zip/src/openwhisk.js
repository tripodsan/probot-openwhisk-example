const createProbot = require('probot');
const { resolve } = require('probot/lib/resolver')
const { findPrivateKey } = require('probot/lib/private-key')
const { template } = require('./views/probot')

const loadProbot = (plugin) => {
  console.log('env', process.env);
  const probot = createProbot({
    id: process.env.APP_ID,
    secret: process.env.WEBHOOK_SECRET,
    cert: findPrivateKey()
  })

  if (typeof plugin === 'string') {
    plugin = resolve(plugin)
  }

  probot.load(plugin)

  return probot
}


module.exports = function install(plugin) {
  return async function main(params) {
    console.log('hello', params);
    // 🤖 A friendly homepage if there isn't a payload
    if (params.__ow_method === 'get' && params.__ow_path === '/probot') {
      return {
        statusCode: 200,
        headers: {
          'Content-Type': 'text/html'
        },
        body: template
      }
    }

    console.log('loading probot...');

    // Otherwise let's listen handle the payload
    const probot = loadProbot(plugin)

    console.log('probot loaded');

    // Ends function immediately after callback
    const headers = params.__ow_headers;

    // Determine incoming webhook event type
    const e = headers['x-github-event'] || headers['X-GitHub-Event']
    const id = headers['x-github-delivery'] || headers['X-GitHub-Delivery']

    console.log('e: %s, id: %s', e, id);

    // Convert the payload to an Object if API Gateway stringifies it
    const body = JSON.parse(Buffer.from(params.__ow_body, 'base64').toString('utf8'));

    console.log('body', body);
    // Do the thing
    console.log(`Received event ${id} ${e}${body.action ? ('.' + body.action) : ''}`)
    if (body) {
      try {
        await probot.receive({
          event: e,
          payload: body
        })
        return {
          statusCode: 200,
          body: JSON.stringify({
            message: 'Hi Node8!'
          })
        }
      } catch (err) {
        console.error(err)
        return err
      }
    } else {
      console.error({ body })
      return {
        statusCode: 500,
        body: 'Unknown error'
      }
    }
  }

}
